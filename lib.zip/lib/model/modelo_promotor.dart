class Promotor{

int id_promotor;
String name;
DateTime dataNacimento;
String cnh;
String rg;
String cpf;
String telefone;
int cd_endereco;
String email;
String senha;

Promotor(
  this.id_promotor,
  this.name,
  this.dataNacimento,
  this.cnh,
  this.rg,
  this.cpf,
  this.telefone,
  this.cd_endereco,
  this.email,
  this.senha,

  );

}
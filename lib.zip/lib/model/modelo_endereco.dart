class Endereco{
    int id;
    String cep;
    String pais;
    String estado;
    String cidade;
    String bairro;
    String rua;
    int numero;
    String? referencia;

    Endereco(
      this.id,
      this.cep,
      this.pais,
      this.estado,
      this.cidade,
      this.bairro,
      this.rua,
      this.numero,
      this.referencia

    );



}